#include <stdio.h>
#include <stdlib.h>

typedef struct {
	int data;
}node;

typedef struct {
	int tree_size;
	node node[50];
}tree;

void insert_tree(tree* t, int item) {
	if (t->tree_size == 0) {
		t->node[1].data = item;
		t->tree_size++;
	}
	else {
		int j = 1;
		while (1) {
			if (item > t->node[j].data) j = 2 * j + 1;
			else if (item < t->node[j].data) j = 2 * j;

			if (t->node[j].data == 0) break;
		}
		t->node[j].data = item;
	}
}

void search_tree(tree* t, int item) {
	int j = 1;
	int try = 0;
	while (1) {
		if (item > t->node[j].data) {
			printf("%d ", t->node[j].data);
			j = 2 * j + 1;
		}
		else if (item < t->node[j].data) {
			printf("%d ", t->node[j].data);
			j = 2 * j;
		}
		else if (item == t->node[j].data) {
			printf("\n%d", try);
			break;
		}
		try++;
	}
}

int main() {

	int N = 0;
	int s = 0;
	scanf("%d", &N);
	scanf("%d", &s);

	int *arr = (int*)malloc(sizeof(int) * N);
	for (int i = 0; i < N; i++) {
		scanf("%d", &arr[i]);
	}

	tree t;
	t.tree_size = 0;
	for (int i = 0; i < 50; i++) {
		t.node[i].data = 0;
	}

	for (int i = 0; i < N; i++) {
		insert_tree(&t, arr[i]);
	}

	search_tree(&t, s);

	return 0;

}
